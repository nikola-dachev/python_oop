from project.dark_knight import DarkKnight


class BlackKnight(DarkKnight):
  pass
